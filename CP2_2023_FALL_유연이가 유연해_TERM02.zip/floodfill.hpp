#include "pixel.hpp"
#include "color.hpp"
#include "shape.hpp"
#include "input.h"
#include <cmath>
Pixel**floodfill(Pixel**str, Color* color,SelectShape & sel,int row, int col);